# WormGPT Studio — GitHub Pages Static Demo

This is a static-only version for GitHub Pages. It does not run Node.js, does not call `/api/chat`, and does not connect to a real AI model. Replies are generated locally in the browser as demo text.

## Publish from GitHub on Android
1. Upload the contents of the `docs` folder to a folder named `docs` in your repository.
2. Open repository **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Select branch `main` and folder `/docs`, then click **Save**.
5. Wait for the deployment, then open the URL shown on the Pages settings screen.

Do not put API keys, passwords, or private data in static JavaScript. Anything published to GitHub Pages is publicly accessible.
