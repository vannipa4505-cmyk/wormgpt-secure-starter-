(() => {
  const $ = (id) => document.getElementById(id);
  const form = $("chatForm"), prompt = $("prompt"), messages = $("messages");
  const welcome = $("welcome"), sidebar = $("sidebar");
  let mode = "ทั่วไป";

  function addMessage(text, who) {
    const row = document.createElement("div");
    row.className = "message " + who;
    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = who === "user" ? "คุณ" : "W";
    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;
    row.append(avatar, bubble);
    messages.appendChild(row);
    row.scrollIntoView({behavior:"smooth", block:"nearest"});
  }

  function demoReply(text) {
    const lower = text.toLowerCase();
    if (mode === "เขียนโค้ด" || lower.includes("html") || lower.includes("โค้ด")) {
      return "นี่คือโหมดสาธิตการเขียนโค้ด\n\nแนวทางเริ่มต้น:\n1. สร้างไฟล์ index.html\n2. เพิ่มโครงสร้าง HTML และเชื่อม style.css\n3. เปิดตรวจในเบราว์เซอร์\n\nหมายเหตุ: คำตอบนี้เป็นตัวอย่างคงที่ ไม่ได้สร้างโดย AI จริง";
    }
    if (mode === "เรียนรู้ความปลอดภัย" || lower.includes("ปลอดภัย") || lower.includes("ความปลอดภัย")) {
      return "แนวทางความปลอดภัยเว็บเบื้องต้น:\n• อย่าใส่ API key หรือรหัสผ่านใน JavaScript ฝั่งหน้าเว็บ\n• ตรวจสอบข้อมูลบนเซิร์ฟเวอร์เมื่อมี backend\n• ใช้ HTTPS และอัปเดต dependencies\n• ทดสอบเฉพาะระบบที่คุณมีสิทธิ์\n\nนี่เป็นข้อความสาธิต ไม่ใช่การตรวจสอบเว็บไซต์จริง";
    }
    return "ได้รับข้อความแล้ว: “" + text + "”\n\nนี่คือ WormGPT Studio เวอร์ชัน Static Demo บน GitHub Pages ซึ่งยังไม่ได้เชื่อมโมเดล AI หรือ API จริง หากต้องการคำตอบจาก AI ต้องเชื่อม backend ที่ปลอดภัยแยกต่างหาก";
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const text = prompt.value.trim();
    if (!text) return;
    welcome.classList.add("hidden");
    addMessage(text, "user");
    prompt.value = "";
    window.setTimeout(() => addMessage(demoReply(text), "assistant"), 250);
  });

  $("newChat").addEventListener("click", () => {
    messages.replaceChildren();
    welcome.classList.remove("hidden");
    prompt.value = "";
    sidebar.classList.remove("open");
  });

  $("toggleMenu").addEventListener("click", () => sidebar.classList.toggle("open"));

  document.querySelectorAll(".menu-item").forEach((button) => {
    button.addEventListener("click", () => {
      mode = button.dataset.mode || "ทั่วไป";
      document.querySelectorAll(".menu-item").forEach((item) => item.classList.toggle("active", item === button));
      sidebar.classList.remove("open");
      addMessage("เปลี่ยนเป็นโหมด: " + mode, "assistant");
    });
  });

  document.querySelectorAll(".suggestion").forEach((button) => {
    button.addEventListener("click", () => {
      prompt.value = button.dataset.prompt || "";
      prompt.focus();
    });
  });
})();